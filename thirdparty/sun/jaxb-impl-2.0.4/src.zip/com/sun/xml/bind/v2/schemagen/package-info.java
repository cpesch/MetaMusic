/**
 * Schema generator.
 *
 * This package hosts the code that generates schemas from
 * {@link TypeInfoSet} (without the user interface.)
 */
package com.sun.xml.bind.v2.schemagen;

import com.sun.xml.bind.v2.model.core.TypeInfoSet;
